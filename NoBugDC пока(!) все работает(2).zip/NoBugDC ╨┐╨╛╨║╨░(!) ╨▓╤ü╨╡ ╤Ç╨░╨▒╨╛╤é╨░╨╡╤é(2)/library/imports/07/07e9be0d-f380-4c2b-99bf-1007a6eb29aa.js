"use strict";
cc._RF.push(module, '07e9b4N84BMK5m/EAem6ymq', 'InfoScript');
// Prefabs/InfoScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        label_prefab: cc.Prefab,
        content_node: cc.Node,
        info_node: cc.Node,
        buildRow_prefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {

        module.exports = {
            content_n: cc.Node,
            node_n: cc.Node,
            function_: cc.Function,
            buildRow_p: cc.Prefab
        };
        module.exports.content_n = this.content_node;
        module.exports.node_n = this.info_node;
        module.exports.function_ = this.CreateTable;
        module.exports.buildRow_p = this.buildRow_prefab;
        this.CreateTable();
    },
    CreateTable: function CreateTable() {
        cc.log("CreateTable function");
        var info = require("InfoScript");
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        var i = 0;
        for (i = parseInt(1); i <= count; i++) {
            cc.sys.localStorage.setItem("id_building", i);
            var row = cc.instantiate(info.buildRow_p);
            info.content_n.addChild(row);
            row.setPosition(0, 100 - i * 200);
            /*
            var building = JSON.parse(cc.sys.localStorage.getItem("building" + i.toString()));
            var str = building.name + ' ' + building.cost + ' ' + building.type;
            cc.log(str);
            cc.sys.localStorage.setItem("info_label_text", str.toString());
            var label = cc.instantiate(this.label_prefab);
            this.content_node.addChild(label);
            label.setPosition(0, 100 - i*200);*/
        }
    }
});

cc._RF.pop();