"use strict";
cc._RF.push(module, '2dbf79F9RlFdaTCwaTLo8m+', 'BuildingRowScript');
// Prefabs/BuildingRowScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        build_name: cc.Label,
        buildingInfo_prefab: cc.Prefab,
        parentNode: cc.Node,
        id: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var build = JSON.parse(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("id_building")));
        cc.log("row log : " + cc.sys.localStorage.getItem("id_building"));
        this.id = cc.sys.localStorage.getItem("id_building");
        this.build_name.string = build.name;
    },
    onClick: function onClick() {
        cc.sys.localStorage.setItem("clickRow", this.id);
        var buildInfo = cc.instantiate(this.buildingInfo_prefab);
        var info = require("InfoScript");
        info.node_n.addChild(buildInfo);
    }
});

cc._RF.pop();