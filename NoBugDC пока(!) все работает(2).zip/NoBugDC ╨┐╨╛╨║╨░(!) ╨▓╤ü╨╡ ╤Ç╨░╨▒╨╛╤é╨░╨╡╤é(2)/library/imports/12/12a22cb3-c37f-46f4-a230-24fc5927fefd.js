"use strict";
cc._RF.push(module, '12a22yzw39G9KIwJPxZJ/79', 'BuildScript');
// Prefabs/BuildScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    Build1: function Build1() {
        var building = {
            name: "B1",
            type: "1",
            cost: 300
        };
        cc.sys.localStorage.setItem("count_buildings", parseInt(parseInt(cc.sys.localStorage.getItem("count_buildings") | 0) + 1));
        cc.log(cc.sys.localStorage.getItem("count_buildings"));
        cc.sys.localStorage.setItem("building" + cc.sys.localStorage.getItem("count_buildings"), JSON.stringify(building));
        cc.log(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("count_buildings")));
    },

    Build2: function Build2() {
        var building = {
            name: "B2",
            type: "2",
            cost: 400
        };
        cc.sys.localStorage.setItem("count_buildings", parseInt(parseInt(cc.sys.localStorage.getItem("count_buildings") | 0) + 1));
        cc.log(cc.sys.localStorage.getItem("count_buildings"));
        cc.sys.localStorage.setItem("building" + cc.sys.localStorage.getItem("count_buildings"), JSON.stringify(building));
        cc.log(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("count_buildings")));
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();