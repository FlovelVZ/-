require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"BuildScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '12a22yzw39G9KIwJPxZJ/79', 'BuildScript');
// Prefabs/BuildScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    Build1: function Build1() {
        var building = {
            name: "B1",
            type: "1",
            cost: 300
        };
        cc.sys.localStorage.setItem("count_buildings", parseInt(parseInt(cc.sys.localStorage.getItem("count_buildings") | 0) + 1));
        cc.log(cc.sys.localStorage.getItem("count_buildings"));
        cc.sys.localStorage.setItem("building" + cc.sys.localStorage.getItem("count_buildings"), JSON.stringify(building));
        cc.log(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("count_buildings")));
    },

    Build2: function Build2() {
        var building = {
            name: "B2",
            type: "2",
            cost: 400
        };
        cc.sys.localStorage.setItem("count_buildings", parseInt(parseInt(cc.sys.localStorage.getItem("count_buildings") | 0) + 1));
        cc.log(cc.sys.localStorage.getItem("count_buildings"));
        cc.sys.localStorage.setItem("building" + cc.sys.localStorage.getItem("count_buildings"), JSON.stringify(building));
        cc.log(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("count_buildings")));
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"BuildingRowInfoScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '1374frhQwFHIYdSElS7eHcB', 'BuildingRowInfoScript');
// Prefabs/BuildingRowInfoScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        infoBuildingNode: cc.Node,
        BuildingName: cc.Label,
        confirmPrefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        var build = JSON.parse(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("clickRow")));
        this.build = build;
        this.BuildingName.string = build.name;
        module.exports = {
            infoBuilding_n: cc.Node
        };
        module.exports.infoBuilding_n = this.infoBuildingNode;
    },
    onClickDestroy: function onClickDestroy() {
        var confirm = cc.instantiate(this.confirmPrefab);
        this.infoBuildingNode.addChild(confirm);
    }
});

cc._RF.pop();
},{}],"BuildingRowScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '2dbf79F9RlFdaTCwaTLo8m+', 'BuildingRowScript');
// Prefabs/BuildingRowScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        build_name: cc.Label,
        buildingInfo_prefab: cc.Prefab,
        parentNode: cc.Node,
        id: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var build = JSON.parse(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("id_building")));
        cc.log("row log : " + cc.sys.localStorage.getItem("id_building"));
        this.id = cc.sys.localStorage.getItem("id_building");
        this.build_name.string = build.name;
    },
    onClick: function onClick() {
        cc.sys.localStorage.setItem("clickRow", this.id);
        var buildInfo = cc.instantiate(this.buildingInfo_prefab);
        var info = require("InfoScript");
        info.node_n.addChild(buildInfo);
    }
});

cc._RF.pop();
},{"InfoScript":"InfoScript"}],"ButtonsMainMenu":[function(require,module,exports){
"use strict";
cc._RF.push(module, '4476aW6nGFDi5Lh85U4saDG', 'ButtonsMainMenu');
// scripts/ButtonsMainMenu.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    newGameBtn: function newGameBtn() {},

    continueGameBtn: function continueGameBtn() {
        cc.director.loadScene("Game");
    },

    settingsBtn: function settingsBtn() {}

});

cc._RF.pop();
},{}],"Childs":[function(require,module,exports){
"use strict";
cc._RF.push(module, '4cbf5js8IFCwJwYwpywA4ym', 'Childs');
// scripts/Childs.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        build_prefab: cc.Prefab,
        Info_prefab: cc.Prefab,
        base_node: cc.Node

    },

    // use this for initialization
    onLoad: function onLoad() {},

    addBuild: function addBuild() {
        var pre = cc.instantiate(this.build_prefab);
        this.node.addChild(pre);
        pre.setPosition(500, 300);
    },

    addInfo: function addInfo() {
        var pre = cc.instantiate(this.Info_prefab);
        this.node.addChild(pre);
        pre.setPosition(500, 300);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"Clear":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'f653esKqGRMB5Uc27fIBOk/', 'Clear');
// scripts/Clear.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    ClearClick: function ClearClick() {
        cc.sys.localStorage.clear();
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"CloseScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '2ed7ehAduxIcYqlQeTxKcnB', 'CloseScript');
// scripts/CloseScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        parentNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},
    CloseBtn: function CloseBtn() {
        this.parentNode.destroy();
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"ConfirmDestroyScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'f2242zcE6tChLbDOC/B0el0', 'ConfirmDestroyScript');
// Prefabs/ConfirmDestroyScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        ConfNode: cc.Node,
        id: 0,
        nameLabel: cc.Label
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.id = cc.sys.localStorage.getItem("clickRow");
        cc.log("ConfirmScript : " + this.id);
        this.nameLabel.string = "Вы уверены, что хотите снести " + JSON.parse(cc.sys.localStorage.getItem("building" + this.id)).name;
    },
    YesBtn: function YesBtn() {
        var i;
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));

        for (i = parseInt(this.id); i < count; i++) {
            var building = {
                name: "",
                type: "",
                cost: 0

            };
            building = JSON.parse(cc.sys.localStorage.getItem("building" + (i + 1).toString()));
            cc.log("ConfirmScript : building" + (i + 1).toString());
            cc.sys.localStorage.setItem("building" + i.toString(), JSON.stringify(building));
        }
        cc.sys.localStorage.setItem("count_buildings", parseInt(cc.sys.localStorage.getItem("count_buildings")) - 1);
        cc.log("ConfirmScript count : " + count);

        var InfoReq = require("InfoScript");
        InfoReq.content_n.removeAllChildren();
        cc.log("ConfirmScript : removeAllChildren");
        count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        InfoReq.function_();

        var buildingInfo = require("BuildingRowInfoScript");
        buildingInfo.infoBuilding_n.destroy();
    },
    NoBtn: function NoBtn() {
        this.ConfNode.destroy();
    }

});

cc._RF.pop();
},{"BuildingRowInfoScript":"BuildingRowInfoScript","InfoScript":"InfoScript"}],"DialogScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'eab6fIhgDdATpmsRUckdJqZ', 'DialogScript');
// Prefabs/DialogScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        dialog_prefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        var randomInc = Math.random();
        cc.log(randomInc);
        cc.log(randomInc > 0.3);
        if (randomInc > 0.0) {
            cc.log(parseInt(randomInc) * 2);
            //var dial = require("Dialogs");
            //cc.sys.localStorage.setItem("DialogString", dial.dialogNumber[parseInt(randomInc)*2]);
            var DialogWindow = cc.instantiate(this.dialog_prefab);
            DialogWindow.setPosition(0, 0);
            this.node.addChild(DialogWindow);
        }
    }

});

cc._RF.pop();
},{}],"Dialogs":[function(require,module,exports){
"use strict";
cc._RF.push(module, '77b08wRxyNCmq3cVLh0KvlF', 'Dialogs');
// Prefabs/Dialogs.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        module.exports = {
            dialogNumber: [""]
        };
        module.exports.dialogNumber[0] = "тралала0";
        module.exports.dialogNumber[1] = "тралала1";
        module.exports.dialogNumber[2] = "тралала2";
    }

});

cc._RF.pop();
},{}],"InfoScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '07e9b4N84BMK5m/EAem6ymq', 'InfoScript');
// Prefabs/InfoScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        label_prefab: cc.Prefab,
        content_node: cc.Node,
        info_node: cc.Node,
        buildRow_prefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {

        module.exports = {
            content_n: cc.Node,
            node_n: cc.Node,
            function_: cc.Function,
            buildRow_p: cc.Prefab
        };
        module.exports.content_n = this.content_node;
        module.exports.node_n = this.info_node;
        module.exports.function_ = this.CreateTable;
        module.exports.buildRow_p = this.buildRow_prefab;
        this.CreateTable();
    },
    CreateTable: function CreateTable() {
        cc.log("CreateTable function");
        var info = require("InfoScript");
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        var i = 0;
        for (i = parseInt(1); i <= count; i++) {
            cc.sys.localStorage.setItem("id_building", i);
            var row = cc.instantiate(info.buildRow_p);
            info.content_n.addChild(row);
            row.setPosition(0, 100 - i * 200);
            /*
            var building = JSON.parse(cc.sys.localStorage.getItem("building" + i.toString()));
            var str = building.name + ' ' + building.cost + ' ' + building.type;
            cc.log(str);
            cc.sys.localStorage.setItem("info_label_text", str.toString());
            var label = cc.instantiate(this.label_prefab);
            this.content_node.addChild(label);
            label.setPosition(0, 100 - i*200);*/
        }
    }
});

cc._RF.pop();
},{"InfoScript":"InfoScript"}],"LabelScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'f8578wd1q9EGawFz+2tG+aJ', 'LabelScript');
// Prefabs/LabelScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        labeltext: cc.Label,
        label_prefab: cc.Prefab,
        id: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.labeltext.string = cc.sys.localStorage.getItem("info_label_text");
        cc.log("lbl " + cc.sys.localStorage.getItem("info_label_text"));
        this.id = parseInt(cc.sys.localStorage.getItem("id_building"));
    },

    onClickDestroy: function onClickDestroy() {
        var i;
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));

        for (i = this.id; i < count; i++) {
            var building = {
                name: "",
                type: "",
                cost: 0

            };
            building = JSON.parse(cc.sys.localStorage.getItem("building" + (i + 1).toString()));
            cc.log("building" + (i + 1).toString());
            cc.sys.localStorage.setItem("building" + i.toString(), JSON.stringify(building));
        }
        cc.sys.localStorage.setItem("count_buildings", parseInt(cc.sys.localStorage.getItem("count_buildings")) - 1);
        cc.log(count);
        var info = require("InfoScript");
        cc.log(info.content_n);
        info.content_n.removeAllChildren();

        count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        i = 0;
        for (i = parseInt(1); i <= count; i++) {
            cc.sys.localStorage.setItem("id_building", i);
            building = JSON.parse(cc.sys.localStorage.getItem("building" + i.toString()));
            var str = building.name + ' ' + building.cost + ' ' + building.type;
            cc.log(str);
            cc.sys.localStorage.setItem("info_label_text", str.toString());
            var label = cc.instantiate(this.label_prefab);
            info.content_n.addChild(label);
            label.setPosition(0, 100 - i * 200);
        }
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"InfoScript":"InfoScript"}],"MapScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '332b1OTy6hCdZlg8XZAuVhU', 'MapScript');
// Prefabs/MapScript.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        sqr: cc.Prefab,
        map_node: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        var i, j;
        for (i = 0; i < 40; i++) {
            for (j = 0; j < 40; j++) {
                var sqr = cc.instantiate(this.sqr);
                sqr.setPosition(i * 21, j * 21);
                this.map_node.addChild(sqr);
            }
        }
    },
    mount: function mount() {},

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.map_node.on(cc.Node.EventType.MOUSE_DOWN, function (event) {
            console.log('Mouse down');
        }, this);
    }
});

cc._RF.pop();
},{}],"Map_sqrScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '62800YN69RJVJeg+Ax49HA6', 'Map_sqrScript');
// Prefabs/Map_sqrScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});

cc._RF.pop();
},{}]},{},["BuildScript","BuildingRowInfoScript","BuildingRowScript","ConfirmDestroyScript","DialogScript","Dialogs","InfoScript","LabelScript","MapScript","Map_sqrScript","ButtonsMainMenu","Childs","Clear","CloseScript"])

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9QcmVmYWJzL0J1aWxkU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvQnVpbGRpbmdSb3dJbmZvU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvQnVpbGRpbmdSb3dTY3JpcHQuanMiLCJhc3NldHMvc2NyaXB0cy9CdXR0b25zTWFpbk1lbnUuanMiLCJhc3NldHMvc2NyaXB0cy9DaGlsZHMuanMiLCJhc3NldHMvc2NyaXB0cy9DbGVhci5qcyIsImFzc2V0cy9zY3JpcHRzL0Nsb3NlU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvQ29uZmlybURlc3Ryb3lTY3JpcHQuanMiLCJhc3NldHMvUHJlZmFicy9EaWFsb2dTY3JpcHQuanMiLCJhc3NldHMvUHJlZmFicy9EaWFsb2dzLmpzIiwiYXNzZXRzL1ByZWZhYnMvSW5mb1NjcmlwdC5qcyIsImFzc2V0cy9QcmVmYWJzL0xhYmVsU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvTWFwU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvTWFwX3NxclNjcmlwdC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVlE7O0FBYVo7QUFDQTs7QUFJQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBSFc7QUFLZjtBQUNBO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFIVztBQUtmO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBL0NLOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYlE7O0FBZ0JaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNJO0FBRGE7QUFHakI7QUFFSDtBQUNEO0FBQ007QUFDQTtBQUNMO0FBakNJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFkUTs7QUFpQlo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBRUg7QUFqQ0k7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWUTs7QUFhWjtBQUNBOztBQUtBOztBQUlBO0FBQ0k7QUFDSDs7QUFFRDs7QUE5Qks7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBYlE7O0FBaUJaO0FBQ0E7O0FBSUE7QUFDSTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDQTs7QUFFQTtBQXZDSzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZROztBQWFaO0FBQ0E7O0FBSUE7QUFDSTtBQUNIO0FBQ0Q7QUFDQTs7QUFFQTtBQTNCSzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWFE7O0FBY1o7QUFDQTtBQUdBO0FBQ0k7QUFDSDtBQUNEO0FBQ0E7O0FBRUE7QUEzQks7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFiUTs7QUFnQlo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBOztBQUVBO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7O0FBSFc7QUFNZjtBQUNBO0FBQ0E7QUFDSDtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNBO0FBQ0o7QUFDRDtBQUNFO0FBQ0Q7O0FBdkRJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFYUTs7QUFjWjtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQUNKOztBQTlCSTs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZROztBQWFaO0FBQ0E7QUFDSTtBQUNJO0FBRGE7QUFHakI7QUFDQTtBQUNBO0FBRUg7O0FBekJJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFkUTs7QUFpQlo7QUFDQTs7QUFFSTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBSmE7QUFNakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNIO0FBQ0Q7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUFRSDtBQUNKO0FBdERJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYlE7O0FBZ0JaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7O0FBRUE7QUFDSTtBQUNJO0FBQ0E7QUFDQTs7QUFIVztBQU1mO0FBQ0E7QUFDQTtBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNEO0FBQ0E7O0FBRUE7QUFoRUs7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWlE7O0FBZVo7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDSjtBQUNEOztBQVFBO0FBQ0M7QUFDRztBQUNJO0FBQ0g7QUFDSDtBQTFDRzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZROztBQWFaO0FBQ0E7O0FBakJLIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG5cbiAgICB9LFxuICAgIFxuICAgIEJ1aWxkMSA6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgYnVpbGRpbmcgPSB7XG4gICAgICAgICAgICBuYW1lIDogXCJCMVwiLFxuICAgICAgICAgICAgdHlwZSA6IFwiMVwiLFxuICAgICAgICAgICAgY29zdCA6IDMwMCxcbiAgICAgICAgfTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIsIHBhcnNlSW50KHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSB8IDApICsgMSkpO1xuICAgICAgICBjYy5sb2coY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIpKTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYnVpbGRpbmdcIiArIGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSwgSlNPTi5zdHJpbmdpZnkoYnVpbGRpbmcpKTtcbiAgICAgICAgY2MubG9nKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJ1aWxkaW5nXCIgKyBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpKTtcbiAgICB9LFxuICAgIFxuICAgIEJ1aWxkMiA6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgYnVpbGRpbmcgPSB7XG4gICAgICAgICAgICBuYW1lIDogXCJCMlwiLFxuICAgICAgICAgICAgdHlwZSA6IFwiMlwiLFxuICAgICAgICAgICAgY29zdCA6IDQwMCxcbiAgICAgICAgfTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIsIHBhcnNlSW50KHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSB8IDApICsgMSkpO1xuICAgICAgICBjYy5sb2coY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIpKTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYnVpbGRpbmdcIiArIGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSwgSlNPTi5zdHJpbmdpZnkoYnVpbGRpbmcpKTtcbiAgICAgICAgY2MubG9nKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJ1aWxkaW5nXCIgKyBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpKTtcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgaW5mb0J1aWxkaW5nTm9kZSA6IGNjLk5vZGUsXG4gICAgICAgIEJ1aWxkaW5nTmFtZSA6IGNjLkxhYmVsLFxuICAgICAgICBjb25maXJtUHJlZmFiIDogY2MuUHJlZmFiLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGJ1aWxkID0gSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJidWlsZGluZ1wiICsgY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY2xpY2tSb3dcIikpKTtcbiAgICAgICAgdGhpcy5idWlsZCA9IGJ1aWxkO1xuICAgICAgICB0aGlzLkJ1aWxkaW5nTmFtZS5zdHJpbmcgPSBidWlsZC5uYW1lO1xuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IHtcbiAgICAgICAgICAgIGluZm9CdWlsZGluZ19uIDogY2MuTm9kZSxcbiAgICAgICAgfTtcbiAgICAgICAgbW9kdWxlLmV4cG9ydHMuaW5mb0J1aWxkaW5nX24gPSB0aGlzLmluZm9CdWlsZGluZ05vZGU7XG4gICAgICAgIFxuICAgIH0sXG4gICAgb25DbGlja0Rlc3Ryb3kgOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICB2YXIgY29uZmlybSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuY29uZmlybVByZWZhYik7XG4gICAgICAgICAgdGhpcy5pbmZvQnVpbGRpbmdOb2RlLmFkZENoaWxkKGNvbmZpcm0pO1xuICAgIH0sXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgYnVpbGRfbmFtZSA6IGNjLkxhYmVsLFxuICAgICAgICBidWlsZGluZ0luZm9fcHJlZmFiIDogY2MuUHJlZmFiLFxuICAgICAgICBwYXJlbnROb2RlIDogY2MuTm9kZSxcbiAgICAgICAgaWQgOiAwLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGJ1aWxkID0gSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJidWlsZGluZ1wiICsgY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaWRfYnVpbGRpbmdcIikpKTtcbiAgICAgICAgY2MubG9nKFwicm93IGxvZyA6IFwiICsgY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaWRfYnVpbGRpbmdcIikpO1xuICAgICAgICB0aGlzLmlkID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaWRfYnVpbGRpbmdcIik7XG4gICAgICAgIHRoaXMuYnVpbGRfbmFtZS5zdHJpbmcgPSBidWlsZC5uYW1lO1xuICAgIH0sXG4gICAgb25DbGljayA6IGZ1bmN0aW9uKCkge1xuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJjbGlja1Jvd1wiLCB0aGlzLmlkKTtcbiAgICAgICAgdmFyIGJ1aWxkSW5mbyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVpbGRpbmdJbmZvX3ByZWZhYik7XG4gICAgICAgIHZhciBpbmZvID0gcmVxdWlyZShcIkluZm9TY3JpcHRcIik7XG4gICAgICAgIGluZm8ubm9kZV9uLmFkZENoaWxkKGJ1aWxkSW5mbyk7XG4gICAgICAgIFxuICAgIH0sXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG5cbiAgICB9LFxuICAgIFxuICAgIFxuICAgIG5ld0dhbWVCdG4gOiBmdW5jdGlvbigpIHtcbiAgICAgICAgXG4gICAgfSxcbiAgICBcbiAgICBjb250aW51ZUdhbWVCdG4gOiBmdW5jdGlvbigpIHtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZVwiKTtcbiAgICB9LFxuICAgIFxuICAgIHNldHRpbmdzQnRuIDogZnVuY3Rpb24oKSB7XG4gICAgICAgIFxuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBidWlsZF9wcmVmYWIgOiBjYy5QcmVmYWIsXG4gICAgICAgIEluZm9fcHJlZmFiIDogY2MuUHJlZmFiLFxuICAgICAgICBiYXNlX25vZGUgOiBjYy5Ob2RlLFxuICAgICAgICBcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG4gICAgIFxuICAgIH0sXG4gICAgXG4gICAgYWRkQnVpbGQgOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHByZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVpbGRfcHJlZmFiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHByZSk7XG4gICAgICAgIHByZS5zZXRQb3NpdGlvbig1MDAsIDMwMCk7XG4gICAgfSxcbiAgICBcbiAgICBhZGRJbmZvIDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBwcmUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkluZm9fcHJlZmFiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHByZSk7XG4gICAgICAgIHByZS5zZXRQb3NpdGlvbig1MDAsIDMwMCk7XG4gICAgfVxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcbiIsImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuXG4gICAgfSxcbiAgICBcbiAgICBDbGVhckNsaWNrIDogZnVuY3Rpb24oKSB7XG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2UuY2xlYXIoKTtcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgcGFyZW50Tm9kZSA6IGNjLk5vZGUsXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuXG4gICAgfSxcbiAgICBDbG9zZUJ0biA6IGZ1bmN0aW9uKCkgeyBcbiAgICAgICAgdGhpcy5wYXJlbnROb2RlLmRlc3Ryb3koKTsgICBcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgQ29uZk5vZGUgOiBjYy5Ob2RlLFxuICAgICAgICBpZCA6IDAsXG4gICAgICAgIG5hbWVMYWJlbCA6IGNjLkxhYmVsLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5pZCA9IGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNsaWNrUm93XCIpO1xuICAgICAgICBjYy5sb2coXCJDb25maXJtU2NyaXB0IDogXCIgKyB0aGlzLmlkKVxuICAgICAgICB0aGlzLm5hbWVMYWJlbC5zdHJpbmcgPSBcItCS0Ysg0YPQstC10YDQtdC90YssINGH0YLQviDRhdC+0YLQuNGC0LUg0YHQvdC10YHRgtC4IFwiICsgSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJidWlsZGluZ1wiICsgdGhpcy5pZCkpLm5hbWU7XG4gICAgfSxcbiAgICBZZXNCdG46IGZ1bmN0aW9uKCkgeyBcbiAgICAgICAgdmFyIGk7XG4gICAgICAgIHZhciBjb3VudCA9IHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSk7XG4gICAgICAgIFxuICAgICAgICBmb3IoaSA9IHBhcnNlSW50KHRoaXMuaWQpOyBpIDwgY291bnQ7IGkrKyl7XG4gICAgICAgICAgICB2YXIgYnVpbGRpbmcgPSB7XG4gICAgICAgICAgICAgICAgbmFtZSA6IFwiXCIsXG4gICAgICAgICAgICAgICAgdHlwZSA6IFwiXCIsXG4gICAgICAgICAgICAgICAgY29zdCA6IDAsXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgYnVpbGRpbmcgPSBKU09OLnBhcnNlKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJ1aWxkaW5nXCIgKyAoaSArIDEpLnRvU3RyaW5nKCkpKTtcbiAgICAgICAgICAgIGNjLmxvZyhcIkNvbmZpcm1TY3JpcHQgOiBidWlsZGluZ1wiICsgKGkgKyAxKS50b1N0cmluZygpKTtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImJ1aWxkaW5nXCIgKyBpLnRvU3RyaW5nKCksIEpTT04uc3RyaW5naWZ5KGJ1aWxkaW5nKSk7XG4gICAgICAgIH1cbiAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiLCBwYXJzZUludChjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpIC0gMSlcbiAgICAgICAgIGNjLmxvZyhcIkNvbmZpcm1TY3JpcHQgY291bnQgOiBcIiArIGNvdW50KTtcbiAgICAgICAgIFxuICAgICAgICAgdmFyIEluZm9SZXEgPSByZXF1aXJlKFwiSW5mb1NjcmlwdFwiKTtcbiAgICAgICAgIEluZm9SZXEuY29udGVudF9uLnJlbW92ZUFsbENoaWxkcmVuKCk7XG4gICAgICAgICBjYy5sb2coXCJDb25maXJtU2NyaXB0IDogcmVtb3ZlQWxsQ2hpbGRyZW5cIik7XG4gICAgICAgICBjb3VudCA9IHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSk7XG4gICAgICAgICBJbmZvUmVxLmZ1bmN0aW9uXygpO1xuICAgICAgICAgXG4gICAgICAgICBcbiAgICAgICAgIHZhciBidWlsZGluZ0luZm8gPSByZXF1aXJlKFwiQnVpbGRpbmdSb3dJbmZvU2NyaXB0XCIpO1xuICAgICAgICAgYnVpbGRpbmdJbmZvLmluZm9CdWlsZGluZ19uLmRlc3Ryb3koKTtcbiAgICB9LFxuICAgIE5vQnRuOiBmdW5jdGlvbigpIHtcbiAgICAgIHRoaXMuQ29uZk5vZGUuZGVzdHJveSgpOyAgXG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcbiIsImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIGRpYWxvZ19wcmVmYWIgOiBjYy5QcmVmYWIsXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgcmFuZG9tSW5jID0gTWF0aC5yYW5kb20oKTtcbiAgICAgICAgY2MubG9nKHJhbmRvbUluYyk7XG4gICAgICAgIGNjLmxvZyhyYW5kb21JbmMgPiAwLjMpO1xuICAgICAgICBpZihyYW5kb21JbmMgPiAwLjApIHtcbiAgICAgICAgICAgIGNjLmxvZyhwYXJzZUludChyYW5kb21JbmMpKjIpO1xuICAgICAgICAgICAgLy92YXIgZGlhbCA9IHJlcXVpcmUoXCJEaWFsb2dzXCIpO1xuICAgICAgICAgICAgLy9jYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJEaWFsb2dTdHJpbmdcIiwgZGlhbC5kaWFsb2dOdW1iZXJbcGFyc2VJbnQocmFuZG9tSW5jKSoyXSk7XG4gICAgICAgICAgICB2YXIgRGlhbG9nV2luZG93ID0gY2MuaW5zdGFudGlhdGUodGhpcy5kaWFsb2dfcHJlZmFiKTsgIFxuICAgICAgICAgICAgRGlhbG9nV2luZG93LnNldFBvc2l0aW9uKDAsIDApO1xuICAgICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKERpYWxvZ1dpbmRvdyk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIG1vZHVsZS5leHBvcnRzID0ge1xuICAgICAgICAgICAgZGlhbG9nTnVtYmVyIDogW1wiXCJdLFxuICAgICAgICB9O1xuICAgICAgICBtb2R1bGUuZXhwb3J0cy5kaWFsb2dOdW1iZXJbMF0gPSBcItGC0YDQsNC70LDQu9CwMFwiO1xuICAgICAgICBtb2R1bGUuZXhwb3J0cy5kaWFsb2dOdW1iZXJbMV0gPSBcItGC0YDQsNC70LDQu9CwMVwiO1xuICAgICAgICBtb2R1bGUuZXhwb3J0cy5kaWFsb2dOdW1iZXJbMl0gPSBcItGC0YDQsNC70LDQu9CwMlwiO1xuICAgICAgICBcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgbGFiZWxfcHJlZmFiIDogY2MuUHJlZmFiLFxuICAgICAgICBjb250ZW50X25vZGUgOiBjYy5Ob2RlLFxuICAgICAgICBpbmZvX25vZGUgOiBjYy5Ob2RlLFxuICAgICAgICBidWlsZFJvd19wcmVmYWIgOiBjYy5QcmVmYWIsXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuICAgICAgICBcbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgICAgICAgICBjb250ZW50X24gOiBjYy5Ob2RlLFxuICAgICAgICAgICAgbm9kZV9uIDogY2MuTm9kZSxcbiAgICAgICAgICAgIGZ1bmN0aW9uXyA6IGNjLkZ1bmN0aW9uLFxuICAgICAgICAgICAgYnVpbGRSb3dfcCA6IGNjLlByZWZhYlxuICAgICAgICB9XG4gICAgICAgIG1vZHVsZS5leHBvcnRzLmNvbnRlbnRfbiA9IHRoaXMuY29udGVudF9ub2RlO1xuICAgICAgICBtb2R1bGUuZXhwb3J0cy5ub2RlX24gPSB0aGlzLmluZm9fbm9kZTtcbiAgICAgICAgbW9kdWxlLmV4cG9ydHMuZnVuY3Rpb25fID0gdGhpcy5DcmVhdGVUYWJsZTtcbiAgICAgICAgbW9kdWxlLmV4cG9ydHMuYnVpbGRSb3dfcCA9IHRoaXMuYnVpbGRSb3dfcHJlZmFiO1xuICAgICAgICB0aGlzLkNyZWF0ZVRhYmxlKCk7XG4gICAgfSxcbiAgICBDcmVhdGVUYWJsZSA6IGZ1bmN0aW9uKCkgeyBcbiAgICAgICAgY2MubG9nKFwiQ3JlYXRlVGFibGUgZnVuY3Rpb25cIik7IFxuICAgICAgICB2YXIgaW5mbyA9IHJlcXVpcmUoXCJJbmZvU2NyaXB0XCIpO1xuICAgICAgICB2YXIgY291bnQgPSBwYXJzZUludChjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpO1xuICAgICAgICB2YXIgaSA9IDA7XG4gICAgICAgIGZvciAoaSA9IHBhcnNlSW50KDEpOyBpIDw9IGNvdW50OyBpKyspe1xuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiaWRfYnVpbGRpbmdcIiwgaSk7XG4gICAgICAgICAgICB2YXIgcm93ID0gY2MuaW5zdGFudGlhdGUoaW5mby5idWlsZFJvd19wKTtcbiAgICAgICAgICAgIGluZm8uY29udGVudF9uLmFkZENoaWxkKHJvdyk7XG4gICAgICAgICAgICByb3cuc2V0UG9zaXRpb24oMCwgMTAwIC0gaSoyMDApO1xuICAgICAgICAgICAgLypcbiAgICAgICAgICAgIHZhciBidWlsZGluZyA9IEpTT04ucGFyc2UoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYnVpbGRpbmdcIiArIGkudG9TdHJpbmcoKSkpO1xuICAgICAgICAgICAgdmFyIHN0ciA9IGJ1aWxkaW5nLm5hbWUgKyAnICcgKyBidWlsZGluZy5jb3N0ICsgJyAnICsgYnVpbGRpbmcudHlwZTtcbiAgICAgICAgICAgIGNjLmxvZyhzdHIpO1xuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiaW5mb19sYWJlbF90ZXh0XCIsIHN0ci50b1N0cmluZygpKTtcbiAgICAgICAgICAgIHZhciBsYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMubGFiZWxfcHJlZmFiKTtcbiAgICAgICAgICAgIHRoaXMuY29udGVudF9ub2RlLmFkZENoaWxkKGxhYmVsKTtcbiAgICAgICAgICAgIGxhYmVsLnNldFBvc2l0aW9uKDAsIDEwMCAtIGkqMjAwKTsqL1xuICAgICAgICB9XG4gICAgfSxcbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBsYWJlbHRleHQgOiBjYy5MYWJlbCxcbiAgICAgICAgbGFiZWxfcHJlZmFiIDogY2MuUHJlZmFiLFxuICAgICAgICBpZCA6IDAsXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuICAgICAgICB0aGlzLmxhYmVsdGV4dC5zdHJpbmcgPSBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJpbmZvX2xhYmVsX3RleHRcIik7XG4gICAgICAgIGNjLmxvZyhcImxibCBcIiArIGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImluZm9fbGFiZWxfdGV4dFwiKSk7XG4gICAgICAgIHRoaXMuaWQgPSBwYXJzZUludChjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJpZF9idWlsZGluZ1wiKSk7XG4gICAgfSxcbiAgICBcbiAgICBvbkNsaWNrRGVzdHJveSA6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgaTtcbiAgICAgICAgdmFyIGNvdW50ID0gcGFyc2VJbnQoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIpKTtcbiAgICAgICAgXG4gICAgICAgIGZvcihpID0gdGhpcy5pZDsgaSA8IGNvdW50OyBpKyspe1xuICAgICAgICAgICAgdmFyIGJ1aWxkaW5nID0ge1xuICAgICAgICAgICAgICAgIG5hbWUgOiBcIlwiLFxuICAgICAgICAgICAgICAgIHR5cGUgOiBcIlwiLFxuICAgICAgICAgICAgICAgIGNvc3QgOiAwLFxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGJ1aWxkaW5nID0gSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJidWlsZGluZ1wiICsgKGkgKyAxKS50b1N0cmluZygpKSk7XG4gICAgICAgICAgICBjYy5sb2coXCJidWlsZGluZ1wiICsgKGkgKyAxKS50b1N0cmluZygpKTtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImJ1aWxkaW5nXCIgKyBpLnRvU3RyaW5nKCksIEpTT04uc3RyaW5naWZ5KGJ1aWxkaW5nKSk7XG4gICAgICAgIH1cbiAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiLCBwYXJzZUludChjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpIC0gMSlcbiAgICAgICAgIGNjLmxvZyhjb3VudCk7XG4gICAgICAgICB2YXIgaW5mbyA9IHJlcXVpcmUoXCJJbmZvU2NyaXB0XCIpO1xuICAgICAgICAgY2MubG9nKGluZm8uY29udGVudF9uKTtcbiAgICAgICAgIGluZm8uY29udGVudF9uLnJlbW92ZUFsbENoaWxkcmVuKCk7XG4gICAgICAgICBcbiAgICAgICAgIFxuICAgICAgICAgY291bnQgPSBwYXJzZUludChjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpO1xuICAgICAgICBpID0gMDtcbiAgICAgICAgZm9yIChpID0gcGFyc2VJbnQoMSk7IGkgPD0gY291bnQ7IGkrKyl7XG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJpZF9idWlsZGluZ1wiLCBpKTtcbiAgICAgICAgICAgIGJ1aWxkaW5nID0gSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJidWlsZGluZ1wiICsgaS50b1N0cmluZygpKSk7XG4gICAgICAgICAgICB2YXIgc3RyID0gYnVpbGRpbmcubmFtZSArICcgJyArIGJ1aWxkaW5nLmNvc3QgKyAnICcgKyBidWlsZGluZy50eXBlO1xuICAgICAgICAgICAgY2MubG9nKHN0cik7XG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJpbmZvX2xhYmVsX3RleHRcIiwgc3RyLnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgdmFyIGxhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5sYWJlbF9wcmVmYWIpO1xuICAgICAgICAgICAgaW5mby5jb250ZW50X24uYWRkQ2hpbGQobGFiZWwpO1xuICAgICAgICAgICAgbGFiZWwuc2V0UG9zaXRpb24oMCwgMTAwIC0gaSoyMDApO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcbiIsImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgICAgIHNxciA6IGNjLlByZWZhYixcbiAgICAgICAgbWFwX25vZGUgOiBjYy5Ob2RlLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGksIGo7XG4gICAgICAgIGZvcihpID0gMDsgaSA8IDQwOyBpKyspe1xuICAgICAgICAgICAgZm9yKGogPSAwOyBqIDwgNDA7IGorKyl7XG4gICAgICAgICAgICAgICAgdmFyIHNxciA9IGNjLmluc3RhbnRpYXRlKHRoaXMuc3FyKTtcbiAgICAgICAgICAgICAgICBzcXIuc2V0UG9zaXRpb24oaSoyMSwgaioyMSk7XG4gICAgICAgICAgICAgICAgdGhpcy5tYXBfbm9kZS5hZGRDaGlsZChzcXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICBtb3VudCA6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgXG4gICAgICAgIFxuICAgIH0sXG4gICAgXG4gICAgXG4gICAgXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgICB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuICAgICAgICB0aGlzLm1hcF9ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLk1PVVNFX0RPV04sIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ01vdXNlIGRvd24nKTtcbiAgICAgICAgfSwgdGhpcyk7XG4gICAgIH0sXG59KTtcbiIsImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuICAgICAgICBcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==