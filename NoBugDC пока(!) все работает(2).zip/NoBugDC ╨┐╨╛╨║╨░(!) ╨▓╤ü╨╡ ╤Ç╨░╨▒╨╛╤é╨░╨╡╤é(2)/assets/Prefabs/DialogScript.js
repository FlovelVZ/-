cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        dialog_prefab : cc.Prefab,
    },

    // use this for initialization
    onLoad: function () {
        var randomInc = Math.random();
        cc.log(randomInc);
        cc.log(randomInc > 0.3);
        if(randomInc > 0.0) {
            cc.log(parseInt(randomInc)*2);
            //var dial = require("Dialogs");
            //cc.sys.localStorage.setItem("DialogString", dial.dialogNumber[parseInt(randomInc)*2]);
            var DialogWindow = cc.instantiate(this.dialog_prefab);  
            DialogWindow.setPosition(0, 0);
            this.node.addChild(DialogWindow);
        }
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
