cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        sqr : cc.Prefab,
        map_node : cc.Node,
    },

    // use this for initialization
    onLoad: function () {
        var i, j;
        for(i = 0; i < 40; i++){
            for(j = 0; j < 40; j++){
                var sqr = cc.instantiate(this.sqr);
                sqr.setPosition(i*21, j*21);
                this.map_node.addChild(sqr);
            }
        }
    },
    mount : function () {
        
        
    },
    
    
    

    // called every frame, uncomment this function to activate update callback
     update: function (dt) {
        this.map_node.on(cc.Node.EventType.MOUSE_DOWN, function (event) {
            console.log('Mouse down');
        }, this);
     },
});
