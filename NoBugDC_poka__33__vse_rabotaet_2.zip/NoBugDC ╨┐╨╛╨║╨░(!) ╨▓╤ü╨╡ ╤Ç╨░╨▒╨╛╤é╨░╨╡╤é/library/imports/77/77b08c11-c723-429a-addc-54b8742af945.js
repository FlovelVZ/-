"use strict";
cc._RF.push(module, '77b08wRxyNCmq3cVLh0KvlF', 'Dialogs');
// Prefabs/Dialogs.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        module.exports = {
            dialogNumber: [""]
        };
        module.exports.dialogNumber[0] = "тралала0";
        module.exports.dialogNumber[1] = "тралала1";
        module.exports.dialogNumber[2] = "тралала2";
    }

});

cc._RF.pop();