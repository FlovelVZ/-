"use strict";
cc._RF.push(module, 'f2242zcE6tChLbDOC/B0el0', 'ConfirmDestroyScript');
// Prefabs/ConfirmDestroyScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        ConfNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},
    YesBtn: function YesBtn() {
        var i;
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));

        for (i = this.id; i < count; i++) {
            var building = {
                name: "",
                type: "",
                cost: 0

            };
            building = JSON.parse(cc.sys.localStorage.getItem("building" + (i + 1).toString()));
            cc.log("building" + (i + 1).toString());
            cc.sys.localStorage.setItem("building" + i.toString(), JSON.stringify(building));
        }
        cc.sys.localStorage.setItem("count_buildings", parseInt(cc.sys.localStorage.getItem("count_buildings")) - 1);
        cc.log(count);
        var info = require("InfoScript");
        cc.log(info.content_n);
        info.content_n.removeAllChildren();

        count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        i = 0;
        for (i = parseInt(1); i <= count; i++) {
            cc.sys.localStorage.setItem("id_building", i);
            var row = cc.instantiate(this.buildRow_prefab);
            info.content_n.addChild(row);
            row.setPosition(0, 100 - i * 200);
            building = JSON.parse(cc.sys.localStorage.getItem("building" + i.toString()));
            var str = building.name + ' ' + building.cost + ' ' + building.type;
            cc.log(str);
            cc.sys.localStorage.setItem("info_label_text", str.toString());
            var label = cc.instantiate(this.label_prefab);
            info.content_n.addChild(label);
            label.setPosition(0, 100 - i * 200);
        }

        this.ConfNode.destroy();
    },
    NoBtn: function NoBtn() {
        this.ConfNode.destroy();
    }

});

cc._RF.pop();