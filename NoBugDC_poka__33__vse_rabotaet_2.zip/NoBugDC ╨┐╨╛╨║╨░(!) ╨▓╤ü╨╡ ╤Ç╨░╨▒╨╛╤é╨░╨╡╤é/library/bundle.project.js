require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"BuildScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '12a22yzw39G9KIwJPxZJ/79', 'BuildScript');
// Prefabs/BuildScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    Build1: function Build1() {
        var building = {
            name: "B1",
            type: "1",
            cost: 300
        };
        cc.sys.localStorage.setItem("count_buildings", parseInt(parseInt(cc.sys.localStorage.getItem("count_buildings") | 0) + 1));
        cc.log(cc.sys.localStorage.getItem("count_buildings"));
        cc.sys.localStorage.setItem("building" + cc.sys.localStorage.getItem("count_buildings"), JSON.stringify(building));
        cc.log(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("count_buildings")));
    },

    Build2: function Build2() {
        var building = {
            name: "B2",
            type: "2",
            cost: 400
        };
        cc.sys.localStorage.setItem("count_buildings", parseInt(parseInt(cc.sys.localStorage.getItem("count_buildings") | 0) + 1));
        cc.log(cc.sys.localStorage.getItem("count_buildings"));
        cc.sys.localStorage.setItem("building" + cc.sys.localStorage.getItem("count_buildings"), JSON.stringify(building));
        cc.log(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("count_buildings")));
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"BuildingRowInfoScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '1374frhQwFHIYdSElS7eHcB', 'BuildingRowInfoScript');
// Prefabs/BuildingRowInfoScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        infoBuildingNode: cc.Node,
        BuildingName: cc.Label,
        confirmPrefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        var build = JSON.parse(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("clickRow")));
        this.build = build;
        this.BuildingName.string = build.name;
    },
    onClickDestroy: function onClickDestroy() {
        var confirm = cc.instantiate(this.confirmPrefab);
        this.infoBuildingNode.addChild(confirm);
    }
});

cc._RF.pop();
},{}],"BuildingRowScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '2dbf79F9RlFdaTCwaTLo8m+', 'BuildingRowScript');
// Prefabs/BuildingRowScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        build_name: cc.Label,
        buildingInfo_prefab: cc.Prefab,
        parentNode: cc.Node,
        id: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        var build = JSON.parse(cc.sys.localStorage.getItem("building" + cc.sys.localStorage.getItem("id_building")));
        cc.log("row log : " + cc.sys.localStorage.getItem("id_building"));
        this.id = cc.sys.localStorage.getItem("id_building");
        this.build_name.string = build.name;
    },
    onClick: function onClick() {
        cc.sys.localStorage.setItem("clickRow", this.id);
        var buildInfo = cc.instantiate(this.buildingInfo_prefab);
        var info = require("InfoScript");
        info.node_n.addChild(buildInfo);
    }
});

cc._RF.pop();
},{"InfoScript":"InfoScript"}],"ButtonsMainMenu":[function(require,module,exports){
"use strict";
cc._RF.push(module, '4476aW6nGFDi5Lh85U4saDG', 'ButtonsMainMenu');
// scripts/ButtonsMainMenu.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    newGameBtn: function newGameBtn() {},

    continueGameBtn: function continueGameBtn() {
        cc.director.loadScene("Game");
    },

    settingsBtn: function settingsBtn() {}

});

cc._RF.pop();
},{}],"Childs":[function(require,module,exports){
"use strict";
cc._RF.push(module, '4cbf5js8IFCwJwYwpywA4ym', 'Childs');
// scripts/Childs.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        build_prefab: cc.Prefab,
        Info_prefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {},

    addBuild: function addBuild() {
        var pre = cc.instantiate(this.build_prefab);
        this.node.addChild(pre);
        pre.setPosition(500, 300);
    },

    addInfo: function addInfo() {
        var pre = cc.instantiate(this.Info_prefab);
        this.node.addChild(pre);
        pre.setPosition(500, 300);
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"Clear":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'f653esKqGRMB5Uc27fIBOk/', 'Clear');
// scripts/Clear.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {},

    ClearClick: function ClearClick() {
        cc.sys.localStorage.clear();
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"CloseScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '2ed7ehAduxIcYqlQeTxKcnB', 'CloseScript');
// scripts/CloseScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        parentNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},
    CloseBtn: function CloseBtn() {
        this.parentNode.destroy();
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{}],"ConfirmDestroyScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'f2242zcE6tChLbDOC/B0el0', 'ConfirmDestroyScript');
// Prefabs/ConfirmDestroyScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        ConfNode: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {},
    YesBtn: function YesBtn() {
        var i;
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));

        for (i = this.id; i < count; i++) {
            var building = {
                name: "",
                type: "",
                cost: 0

            };
            building = JSON.parse(cc.sys.localStorage.getItem("building" + (i + 1).toString()));
            cc.log("building" + (i + 1).toString());
            cc.sys.localStorage.setItem("building" + i.toString(), JSON.stringify(building));
        }
        cc.sys.localStorage.setItem("count_buildings", parseInt(cc.sys.localStorage.getItem("count_buildings")) - 1);
        cc.log(count);
        var info = require("InfoScript");
        cc.log(info.content_n);
        info.content_n.removeAllChildren();

        count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        i = 0;
        for (i = parseInt(1); i <= count; i++) {
            cc.sys.localStorage.setItem("id_building", i);
            var row = cc.instantiate(this.buildRow_prefab);
            info.content_n.addChild(row);
            row.setPosition(0, 100 - i * 200);
            building = JSON.parse(cc.sys.localStorage.getItem("building" + i.toString()));
            var str = building.name + ' ' + building.cost + ' ' + building.type;
            cc.log(str);
            cc.sys.localStorage.setItem("info_label_text", str.toString());
            var label = cc.instantiate(this.label_prefab);
            info.content_n.addChild(label);
            label.setPosition(0, 100 - i * 200);
        }

        this.ConfNode.destroy();
    },
    NoBtn: function NoBtn() {
        this.ConfNode.destroy();
    }

});

cc._RF.pop();
},{"InfoScript":"InfoScript"}],"DialogScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'eab6fIhgDdATpmsRUckdJqZ', 'DialogScript');
// Prefabs/DialogScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        dialog_prefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        var randomInc = Math.random();
        cc.log(randomInc);
        cc.log(randomInc > 0.3);
        if (randomInc > 0.0) {
            cc.log(parseInt(randomInc) * 2);
            //var dial = require("Dialogs");
            //cc.sys.localStorage.setItem("DialogString", dial.dialogNumber[parseInt(randomInc)*2]);
            var DialogWindow = cc.instantiate(this.dialog_prefab);
            DialogWindow.setPosition(0, 0);
            this.node.addChild(DialogWindow);
        }
    }

});

cc._RF.pop();
},{}],"Dialogs":[function(require,module,exports){
"use strict";
cc._RF.push(module, '77b08wRxyNCmq3cVLh0KvlF', 'Dialogs');
// Prefabs/Dialogs.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {
        module.exports = {
            dialogNumber: [""]
        };
        module.exports.dialogNumber[0] = "тралала0";
        module.exports.dialogNumber[1] = "тралала1";
        module.exports.dialogNumber[2] = "тралала2";
    }

});

cc._RF.pop();
},{}],"InfoScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '07e9b4N84BMK5m/EAem6ymq', 'InfoScript');
// Prefabs/InfoScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        label_prefab: cc.Prefab,
        content_node: cc.Node,
        info_node: cc.Node,
        buildRow_prefab: cc.Prefab
    },

    // use this for initialization
    onLoad: function onLoad() {
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        var i = 0;
        for (i = parseInt(1); i <= count; i++) {
            cc.sys.localStorage.setItem("id_building", i);
            var row = cc.instantiate(this.buildRow_prefab);
            this.content_node.addChild(row);
            row.setPosition(0, 100 - i * 200);
            var building = JSON.parse(cc.sys.localStorage.getItem("building" + i.toString()));
            var str = building.name + ' ' + building.cost + ' ' + building.type;
            cc.log(str);
            cc.sys.localStorage.setItem("info_label_text", str.toString());
            var label = cc.instantiate(this.label_prefab);
            this.content_node.addChild(label);
            label.setPosition(0, 100 - i * 200);
        }
        module.exports = {
            content_n: cc.Node,
            node_n: cc.Node
        };
        module.exports.content_n = this.content_node;
        module.exports.node_n = this.info_node;
    }

});

cc._RF.pop();
},{}],"LabelScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, 'f8578wd1q9EGawFz+2tG+aJ', 'LabelScript');
// Prefabs/LabelScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        labeltext: cc.Label,
        label_prefab: cc.Prefab,
        id: 0
    },

    // use this for initialization
    onLoad: function onLoad() {
        this.labeltext.string = cc.sys.localStorage.getItem("info_label_text");
        cc.log("lbl " + cc.sys.localStorage.getItem("info_label_text"));
        this.id = parseInt(cc.sys.localStorage.getItem("id_building"));
    },

    onClickDestroy: function onClickDestroy() {
        var i;
        var count = parseInt(cc.sys.localStorage.getItem("count_buildings"));

        for (i = this.id; i < count; i++) {
            var building = {
                name: "",
                type: "",
                cost: 0

            };
            building = JSON.parse(cc.sys.localStorage.getItem("building" + (i + 1).toString()));
            cc.log("building" + (i + 1).toString());
            cc.sys.localStorage.setItem("building" + i.toString(), JSON.stringify(building));
        }
        cc.sys.localStorage.setItem("count_buildings", parseInt(cc.sys.localStorage.getItem("count_buildings")) - 1);
        cc.log(count);
        var info = require("InfoScript");
        cc.log(info.content_n);
        info.content_n.removeAllChildren();

        count = parseInt(cc.sys.localStorage.getItem("count_buildings"));
        i = 0;
        for (i = parseInt(1); i <= count; i++) {
            cc.sys.localStorage.setItem("id_building", i);
            building = JSON.parse(cc.sys.localStorage.getItem("building" + i.toString()));
            var str = building.name + ' ' + building.cost + ' ' + building.type;
            cc.log(str);
            cc.sys.localStorage.setItem("info_label_text", str.toString());
            var label = cc.instantiate(this.label_prefab);
            info.content_n.addChild(label);
            label.setPosition(0, 100 - i * 200);
        }
    }
    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
},{"InfoScript":"InfoScript"}],"MapScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '332b1OTy6hCdZlg8XZAuVhU', 'MapScript');
// Prefabs/MapScript.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        sqr: cc.Prefab,
        map_node: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        var i, j;
        for (i = 0; i < 40; i++) {
            for (j = 0; j < 40; j++) {
                var sqr = cc.instantiate(this.sqr);
                sqr.setPosition(i * 21, j * 21);
                this.map_node.addChild(sqr);
            }
        }
    },
    mount: function mount() {},

    // called every frame, uncomment this function to activate update callback
    update: function update(dt) {
        this.map_node.on(cc.Node.EventType.MOUSE_DOWN, function (event) {
            console.log('Mouse down');
        }, this);
    }
});

cc._RF.pop();
},{}],"Map_sqrScript":[function(require,module,exports){
"use strict";
cc._RF.push(module, '62800YN69RJVJeg+Ax49HA6', 'Map_sqrScript');
// Prefabs/Map_sqrScript.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },

    // use this for initialization
    onLoad: function onLoad() {}

});

cc._RF.pop();
},{}]},{},["BuildScript","BuildingRowInfoScript","BuildingRowScript","ConfirmDestroyScript","DialogScript","Dialogs","InfoScript","LabelScript","MapScript","Map_sqrScript","ButtonsMainMenu","Childs","Clear","CloseScript"])

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0cy9QcmVmYWJzL0J1aWxkU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvQnVpbGRpbmdSb3dJbmZvU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvQnVpbGRpbmdSb3dTY3JpcHQuanMiLCJhc3NldHMvc2NyaXB0cy9CdXR0b25zTWFpbk1lbnUuanMiLCJhc3NldHMvc2NyaXB0cy9DaGlsZHMuanMiLCJhc3NldHMvc2NyaXB0cy9DbGVhci5qcyIsImFzc2V0cy9zY3JpcHRzL0Nsb3NlU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvQ29uZmlybURlc3Ryb3lTY3JpcHQuanMiLCJhc3NldHMvUHJlZmFicy9EaWFsb2dTY3JpcHQuanMiLCJhc3NldHMvUHJlZmFicy9EaWFsb2dzLmpzIiwiYXNzZXRzL1ByZWZhYnMvSW5mb1NjcmlwdC5qcyIsImFzc2V0cy9QcmVmYWJzL0xhYmVsU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvTWFwU2NyaXB0LmpzIiwiYXNzZXRzL1ByZWZhYnMvTWFwX3NxclNjcmlwdC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVlE7O0FBYVo7QUFDQTs7QUFJQTtBQUNJO0FBQ0k7QUFDQTtBQUNBO0FBSFc7QUFLZjtBQUNBO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDSTtBQUNBO0FBQ0E7QUFIVztBQUtmO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBL0NLOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYlE7O0FBZ0JaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDtBQUNEO0FBQ007QUFDQTtBQUNMO0FBNUJJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFkUTs7QUFpQlo7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBRUg7QUFqQ0k7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWUTs7QUFhWjtBQUNBOztBQUtBOztBQUlBO0FBQ0k7QUFDSDs7QUFFRDs7QUE5Qks7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWlE7O0FBZVo7QUFDQTs7QUFJQTtBQUNJO0FBQ0E7QUFDQTtBQUNIOztBQUVEO0FBQ0k7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBckNLOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVlE7O0FBYVo7QUFDQTs7QUFJQTtBQUNJO0FBQ0g7QUFDRDtBQUNBOztBQUVBO0FBM0JLOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFYUTs7QUFjWjtBQUNBO0FBR0E7QUFDSTtBQUNIO0FBQ0Q7QUFDQTs7QUFFQTtBQTNCSzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWFE7O0FBY1o7QUFDQTtBQUdBO0FBQ0k7QUFDQTs7QUFFQTtBQUNJO0FBQ0k7QUFDQTtBQUNBOztBQUhXO0FBTWY7QUFDQTtBQUNBO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBO0FBQ0Q7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNIO0FBQ0Q7QUFDRTtBQUNEOztBQS9ESTs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWFE7O0FBY1o7QUFDQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjs7QUE5Qkk7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWUTs7QUFhWjtBQUNBO0FBQ0k7QUFDSTtBQURhO0FBR2pCO0FBQ0E7QUFDQTtBQUVIOztBQXpCSTs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBZFE7O0FBaUJaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDRDtBQUNJO0FBQ0E7QUFGYTtBQUlqQjtBQUNBO0FBQ0g7O0FBM0NJOzs7Ozs7Ozs7O0FDQVQ7QUFDSTs7QUFFQTtBQUNJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBYlE7O0FBZ0JaO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDSDs7QUFFRDtBQUNJO0FBQ0E7O0FBRUE7QUFDSTtBQUNJO0FBQ0E7QUFDQTs7QUFIVztBQU1mO0FBQ0E7QUFDQTtBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQTtBQUNEO0FBQ0E7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7QUFDSjtBQUNEO0FBQ0E7O0FBRUE7QUFoRUs7Ozs7Ozs7Ozs7QUNBVDtBQUNJOztBQUVBO0FBQ0k7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBWlE7O0FBZVo7QUFDQTtBQUNJO0FBQ0E7QUFDSTtBQUNJO0FBQ0E7QUFDQTtBQUNIO0FBQ0o7QUFDSjtBQUNEOztBQVFBO0FBQ0M7QUFDRztBQUNJO0FBQ0g7QUFDSDtBQTFDRzs7Ozs7Ozs7OztBQ0FUO0FBQ0k7O0FBRUE7QUFDSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZROztBQWFaO0FBQ0E7O0FBakJLIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG5cbiAgICB9LFxuICAgIFxuICAgIEJ1aWxkMSA6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgYnVpbGRpbmcgPSB7XG4gICAgICAgICAgICBuYW1lIDogXCJCMVwiLFxuICAgICAgICAgICAgdHlwZSA6IFwiMVwiLFxuICAgICAgICAgICAgY29zdCA6IDMwMCxcbiAgICAgICAgfTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIsIHBhcnNlSW50KHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSB8IDApICsgMSkpO1xuICAgICAgICBjYy5sb2coY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIpKTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYnVpbGRpbmdcIiArIGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSwgSlNPTi5zdHJpbmdpZnkoYnVpbGRpbmcpKTtcbiAgICAgICAgY2MubG9nKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJ1aWxkaW5nXCIgKyBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpKTtcbiAgICB9LFxuICAgIFxuICAgIEJ1aWxkMiA6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgYnVpbGRpbmcgPSB7XG4gICAgICAgICAgICBuYW1lIDogXCJCMlwiLFxuICAgICAgICAgICAgdHlwZSA6IFwiMlwiLFxuICAgICAgICAgICAgY29zdCA6IDQwMCxcbiAgICAgICAgfTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIsIHBhcnNlSW50KHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSB8IDApICsgMSkpO1xuICAgICAgICBjYy5sb2coY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIpKTtcbiAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYnVpbGRpbmdcIiArIGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSwgSlNPTi5zdHJpbmdpZnkoYnVpbGRpbmcpKTtcbiAgICAgICAgY2MubG9nKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJ1aWxkaW5nXCIgKyBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpKTtcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgaW5mb0J1aWxkaW5nTm9kZSA6IGNjLk5vZGUsXG4gICAgICAgIEJ1aWxkaW5nTmFtZSA6IGNjLkxhYmVsLFxuICAgICAgICBjb25maXJtUHJlZmFiIDogY2MuUHJlZmFiLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGJ1aWxkID0gSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJidWlsZGluZ1wiICsgY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY2xpY2tSb3dcIikpKTtcbiAgICAgICAgdGhpcy5idWlsZCA9IGJ1aWxkO1xuICAgICAgICB0aGlzLkJ1aWxkaW5nTmFtZS5zdHJpbmcgPSBidWlsZC5uYW1lO1xuICAgIH0sXG4gICAgb25DbGlja0Rlc3Ryb3kgOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICB2YXIgY29uZmlybSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuY29uZmlybVByZWZhYik7XG4gICAgICAgICAgdGhpcy5pbmZvQnVpbGRpbmdOb2RlLmFkZENoaWxkKGNvbmZpcm0pO1xuICAgIH0sXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgYnVpbGRfbmFtZSA6IGNjLkxhYmVsLFxuICAgICAgICBidWlsZGluZ0luZm9fcHJlZmFiIDogY2MuUHJlZmFiLFxuICAgICAgICBwYXJlbnROb2RlIDogY2MuTm9kZSxcbiAgICAgICAgaWQgOiAwLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGJ1aWxkID0gSlNPTi5wYXJzZShjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJidWlsZGluZ1wiICsgY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaWRfYnVpbGRpbmdcIikpKTtcbiAgICAgICAgY2MubG9nKFwicm93IGxvZyA6IFwiICsgY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaWRfYnVpbGRpbmdcIikpO1xuICAgICAgICB0aGlzLmlkID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaWRfYnVpbGRpbmdcIik7XG4gICAgICAgIHRoaXMuYnVpbGRfbmFtZS5zdHJpbmcgPSBidWlsZC5uYW1lO1xuICAgIH0sXG4gICAgb25DbGljayA6IGZ1bmN0aW9uKCkge1xuICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJjbGlja1Jvd1wiLCB0aGlzLmlkKTtcbiAgICAgICAgdmFyIGJ1aWxkSW5mbyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVpbGRpbmdJbmZvX3ByZWZhYik7XG4gICAgICAgIHZhciBpbmZvID0gcmVxdWlyZShcIkluZm9TY3JpcHRcIik7XG4gICAgICAgIGluZm8ubm9kZV9uLmFkZENoaWxkKGJ1aWxkSW5mbyk7XG4gICAgICAgIFxuICAgIH0sXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG5cbiAgICB9LFxuICAgIFxuICAgIFxuICAgIG5ld0dhbWVCdG4gOiBmdW5jdGlvbigpIHtcbiAgICAgICAgXG4gICAgfSxcbiAgICBcbiAgICBjb250aW51ZUdhbWVCdG4gOiBmdW5jdGlvbigpIHtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZVwiKTtcbiAgICB9LFxuICAgIFxuICAgIHNldHRpbmdzQnRuIDogZnVuY3Rpb24oKSB7XG4gICAgICAgIFxuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBidWlsZF9wcmVmYWIgOiBjYy5QcmVmYWIsXG4gICAgICAgIEluZm9fcHJlZmFiIDogY2MuUHJlZmFiLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcblxuICAgIH0sXG4gICAgXG4gICAgYWRkQnVpbGQgOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHByZSA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVpbGRfcHJlZmFiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHByZSk7XG4gICAgICAgIHByZS5zZXRQb3NpdGlvbig1MDAsIDMwMCk7XG4gICAgfSxcbiAgICBcbiAgICBhZGRJbmZvIDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBwcmUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkluZm9fcHJlZmFiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKHByZSk7XG4gICAgICAgIHByZS5zZXRQb3NpdGlvbig1MDAsIDMwMCk7XG4gICAgfVxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcbiIsImNjLkNsYXNzKHtcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXG5cbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIC8vIGZvbzoge1xuICAgICAgICAvLyAgICBkZWZhdWx0OiBudWxsLCAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgIC8vICAgIHVybDogY2MuVGV4dHVyZTJELCAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcbiAgICAgICAgLy8gICAgc2VyaWFsaXphYmxlOiB0cnVlLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIHZpc2libGU6IHRydWUsICAgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICBkaXNwbGF5TmFtZTogJ0ZvbycsIC8vIG9wdGlvbmFsXG4gICAgICAgIC8vICAgIHJlYWRvbmx5OiBmYWxzZSwgICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgZmFsc2VcbiAgICAgICAgLy8gfSxcbiAgICAgICAgLy8gLi4uXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuXG4gICAgfSxcbiAgICBcbiAgICBDbGVhckNsaWNrIDogZnVuY3Rpb24oKSB7XG4gICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2UuY2xlYXIoKTtcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgcGFyZW50Tm9kZSA6IGNjLk5vZGUsXG4gICAgfSxcblxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxuICAgIG9uTG9hZDogZnVuY3Rpb24gKCkge1xuXG4gICAgfSxcbiAgICBDbG9zZUJ0biA6IGZ1bmN0aW9uKCkgeyBcbiAgICAgICAgdGhpcy5wYXJlbnROb2RlLmRlc3Ryb3koKTsgICBcbiAgICB9XG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgQ29uZk5vZGUgOiBjYy5Ob2RlLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcblxuICAgIH0sXG4gICAgWWVzQnRuOiBmdW5jdGlvbigpIHsgXG4gICAgICAgIHZhciBpO1xuICAgICAgICB2YXIgY291bnQgPSBwYXJzZUludChjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIikpO1xuICAgICAgICBcbiAgICAgICAgZm9yKGkgPSB0aGlzLmlkOyBpIDwgY291bnQ7IGkrKyl7XG4gICAgICAgICAgICB2YXIgYnVpbGRpbmcgPSB7XG4gICAgICAgICAgICAgICAgbmFtZSA6IFwiXCIsXG4gICAgICAgICAgICAgICAgdHlwZSA6IFwiXCIsXG4gICAgICAgICAgICAgICAgY29zdCA6IDAsXG4gICAgICAgICAgICAgICAgXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgYnVpbGRpbmcgPSBKU09OLnBhcnNlKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJ1aWxkaW5nXCIgKyAoaSArIDEpLnRvU3RyaW5nKCkpKTtcbiAgICAgICAgICAgIGNjLmxvZyhcImJ1aWxkaW5nXCIgKyAoaSArIDEpLnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYnVpbGRpbmdcIiArIGkudG9TdHJpbmcoKSwgSlNPTi5zdHJpbmdpZnkoYnVpbGRpbmcpKTtcbiAgICAgICAgfVxuICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIsIHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSkgLSAxKVxuICAgICAgICAgY2MubG9nKGNvdW50KTtcbiAgICAgICAgIHZhciBpbmZvID0gcmVxdWlyZShcIkluZm9TY3JpcHRcIik7XG4gICAgICAgICBjYy5sb2coaW5mby5jb250ZW50X24pO1xuICAgICAgICAgaW5mby5jb250ZW50X24ucmVtb3ZlQWxsQ2hpbGRyZW4oKTtcbiAgICAgICAgIFxuICAgICAgICAgXG4gICAgICAgICBjb3VudCA9IHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSk7XG4gICAgICAgIGkgPSAwO1xuICAgICAgICBmb3IgKGkgPSBwYXJzZUludCgxKTsgaSA8PSBjb3VudDsgaSsrKXtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImlkX2J1aWxkaW5nXCIsIGkpO1xuICAgICAgICAgICAgdmFyIHJvdyA9IGNjLmluc3RhbnRpYXRlKHRoaXMuYnVpbGRSb3dfcHJlZmFiKTtcbiAgICAgICAgICAgIGluZm8uY29udGVudF9uLmFkZENoaWxkKHJvdyk7XG4gICAgICAgICAgICByb3cuc2V0UG9zaXRpb24oMCwgMTAwIC0gaSoyMDApO1xuICAgICAgICAgICAgYnVpbGRpbmcgPSBKU09OLnBhcnNlKGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImJ1aWxkaW5nXCIgKyBpLnRvU3RyaW5nKCkpKTtcbiAgICAgICAgICAgIHZhciBzdHIgPSBidWlsZGluZy5uYW1lICsgJyAnICsgYnVpbGRpbmcuY29zdCArICcgJyArIGJ1aWxkaW5nLnR5cGU7XG4gICAgICAgICAgICBjYy5sb2coc3RyKTtcbiAgICAgICAgICAgIGNjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcImluZm9fbGFiZWxfdGV4dFwiLCBzdHIudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICB2YXIgbGFiZWwgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmxhYmVsX3ByZWZhYik7XG4gICAgICAgICAgICBpbmZvLmNvbnRlbnRfbi5hZGRDaGlsZChsYWJlbCk7XG4gICAgICAgICAgICBsYWJlbC5zZXRQb3NpdGlvbigwLCAxMDAgLSBpKjIwMCk7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgICAgIHRoaXMuQ29uZk5vZGUuZGVzdHJveSgpO1xuICAgIH0sXG4gICAgTm9CdG46IGZ1bmN0aW9uKCkge1xuICAgICAgdGhpcy5Db25mTm9kZS5kZXN0cm95KCk7ICBcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgZGlhbG9nX3ByZWZhYiA6IGNjLlByZWZhYixcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciByYW5kb21JbmMgPSBNYXRoLnJhbmRvbSgpO1xuICAgICAgICBjYy5sb2cocmFuZG9tSW5jKTtcbiAgICAgICAgY2MubG9nKHJhbmRvbUluYyA+IDAuMyk7XG4gICAgICAgIGlmKHJhbmRvbUluYyA+IDAuMCkge1xuICAgICAgICAgICAgY2MubG9nKHBhcnNlSW50KHJhbmRvbUluYykqMik7XG4gICAgICAgICAgICAvL3ZhciBkaWFsID0gcmVxdWlyZShcIkRpYWxvZ3NcIik7XG4gICAgICAgICAgICAvL2NjLnN5cy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShcIkRpYWxvZ1N0cmluZ1wiLCBkaWFsLmRpYWxvZ051bWJlcltwYXJzZUludChyYW5kb21JbmMpKjJdKTtcbiAgICAgICAgICAgIHZhciBEaWFsb2dXaW5kb3cgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmRpYWxvZ19wcmVmYWIpOyAgXG4gICAgICAgICAgICBEaWFsb2dXaW5kb3cuc2V0UG9zaXRpb24oMCwgMCk7XG4gICAgICAgICAgICB0aGlzLm5vZGUuYWRkQ2hpbGQoRGlhbG9nV2luZG93KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgICAgICAgICBkaWFsb2dOdW1iZXIgOiBbXCJcIl0sXG4gICAgICAgIH07XG4gICAgICAgIG1vZHVsZS5leHBvcnRzLmRpYWxvZ051bWJlclswXSA9IFwi0YLRgNCw0LvQsNC70LAwXCI7XG4gICAgICAgIG1vZHVsZS5leHBvcnRzLmRpYWxvZ051bWJlclsxXSA9IFwi0YLRgNCw0LvQsNC70LAxXCI7XG4gICAgICAgIG1vZHVsZS5leHBvcnRzLmRpYWxvZ051bWJlclsyXSA9IFwi0YLRgNCw0LvQsNC70LAyXCI7XG4gICAgICAgIFxuICAgIH0sXG5cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBsYWJlbF9wcmVmYWIgOiBjYy5QcmVmYWIsXG4gICAgICAgIGNvbnRlbnRfbm9kZSA6IGNjLk5vZGUsXG4gICAgICAgIGluZm9fbm9kZSA6IGNjLk5vZGUsXG4gICAgICAgIGJ1aWxkUm93X3ByZWZhYiA6IGNjLlByZWZhYixcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBjb3VudCA9IHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSk7XG4gICAgICAgIHZhciBpID0gMDtcbiAgICAgICAgZm9yIChpID0gcGFyc2VJbnQoMSk7IGkgPD0gY291bnQ7IGkrKyl7XG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJpZF9idWlsZGluZ1wiLCBpKTtcbiAgICAgICAgICAgIHZhciByb3cgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJ1aWxkUm93X3ByZWZhYik7XG4gICAgICAgICAgICB0aGlzLmNvbnRlbnRfbm9kZS5hZGRDaGlsZChyb3cpO1xuICAgICAgICAgICAgcm93LnNldFBvc2l0aW9uKDAsIDEwMCAtIGkqMjAwKTtcbiAgICAgICAgICAgIHZhciBidWlsZGluZyA9IEpTT04ucGFyc2UoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYnVpbGRpbmdcIiArIGkudG9TdHJpbmcoKSkpO1xuICAgICAgICAgICAgdmFyIHN0ciA9IGJ1aWxkaW5nLm5hbWUgKyAnICcgKyBidWlsZGluZy5jb3N0ICsgJyAnICsgYnVpbGRpbmcudHlwZTtcbiAgICAgICAgICAgIGNjLmxvZyhzdHIpO1xuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiaW5mb19sYWJlbF90ZXh0XCIsIHN0ci50b1N0cmluZygpKTtcbiAgICAgICAgICAgIHZhciBsYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMubGFiZWxfcHJlZmFiKTtcbiAgICAgICAgICAgIHRoaXMuY29udGVudF9ub2RlLmFkZENoaWxkKGxhYmVsKTtcbiAgICAgICAgICAgIGxhYmVsLnNldFBvc2l0aW9uKDAsIDEwMCAtIGkqMjAwKTtcbiAgICAgICAgfVxuICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IHtcbiAgICAgICAgICAgIGNvbnRlbnRfbiA6IGNjLk5vZGUsXG4gICAgICAgICAgICBub2RlX24gOiBjYy5Ob2RlLFxuICAgICAgICB9XG4gICAgICAgIG1vZHVsZS5leHBvcnRzLmNvbnRlbnRfbiA9IHRoaXMuY29udGVudF9ub2RlO1xuICAgICAgICBtb2R1bGUuZXhwb3J0cy5ub2RlX24gPSB0aGlzLmluZm9fbm9kZTtcbiAgICB9LFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAvLyB1cGRhdGU6IGZ1bmN0aW9uIChkdCkge1xuXG4gICAgLy8gfSxcbn0pO1xuIiwiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgLy8gZm9vOiB7XG4gICAgICAgIC8vICAgIGRlZmF1bHQ6IG51bGwsICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgLy8gICAgdXJsOiBjYy5UZXh0dXJlMkQsICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxuICAgICAgICAvLyAgICBzZXJpYWxpemFibGU6IHRydWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgdmlzaWJsZTogdHJ1ZSwgICAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXG4gICAgICAgIC8vICAgIGRpc3BsYXlOYW1lOiAnRm9vJywgLy8gb3B0aW9uYWxcbiAgICAgICAgLy8gICAgcmVhZG9ubHk6IGZhbHNlLCAgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyBmYWxzZVxuICAgICAgICAvLyB9LFxuICAgICAgICAvLyAuLi5cbiAgICAgICAgbGFiZWx0ZXh0IDogY2MuTGFiZWwsXG4gICAgICAgIGxhYmVsX3ByZWZhYiA6IGNjLlByZWZhYixcbiAgICAgICAgaWQgOiAwLFxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhpcy5sYWJlbHRleHQuc3RyaW5nID0gY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaW5mb19sYWJlbF90ZXh0XCIpO1xuICAgICAgICBjYy5sb2coXCJsYmwgXCIgKyBjYy5zeXMubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJpbmZvX2xhYmVsX3RleHRcIikpO1xuICAgICAgICB0aGlzLmlkID0gcGFyc2VJbnQoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiaWRfYnVpbGRpbmdcIikpO1xuICAgIH0sXG4gICAgXG4gICAgb25DbGlja0Rlc3Ryb3kgOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGk7XG4gICAgICAgIHZhciBjb3VudCA9IHBhcnNlSW50KGNjLnN5cy5sb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImNvdW50X2J1aWxkaW5nc1wiKSk7XG4gICAgICAgIFxuICAgICAgICBmb3IoaSA9IHRoaXMuaWQ7IGkgPCBjb3VudDsgaSsrKXtcbiAgICAgICAgICAgIHZhciBidWlsZGluZyA9IHtcbiAgICAgICAgICAgICAgICBuYW1lIDogXCJcIixcbiAgICAgICAgICAgICAgICB0eXBlIDogXCJcIixcbiAgICAgICAgICAgICAgICBjb3N0IDogMCxcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBidWlsZGluZyA9IEpTT04ucGFyc2UoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYnVpbGRpbmdcIiArIChpICsgMSkudG9TdHJpbmcoKSkpO1xuICAgICAgICAgICAgY2MubG9nKFwiYnVpbGRpbmdcIiArIChpICsgMSkudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJidWlsZGluZ1wiICsgaS50b1N0cmluZygpLCBKU09OLnN0cmluZ2lmeShidWlsZGluZykpO1xuICAgICAgICB9XG4gICAgICAgICBjYy5zeXMubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJjb3VudF9idWlsZGluZ3NcIiwgcGFyc2VJbnQoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIpKSAtIDEpXG4gICAgICAgICBjYy5sb2coY291bnQpO1xuICAgICAgICAgdmFyIGluZm8gPSByZXF1aXJlKFwiSW5mb1NjcmlwdFwiKTtcbiAgICAgICAgIGNjLmxvZyhpbmZvLmNvbnRlbnRfbik7XG4gICAgICAgICBpbmZvLmNvbnRlbnRfbi5yZW1vdmVBbGxDaGlsZHJlbigpO1xuICAgICAgICAgXG4gICAgICAgICBcbiAgICAgICAgIGNvdW50ID0gcGFyc2VJbnQoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiY291bnRfYnVpbGRpbmdzXCIpKTtcbiAgICAgICAgaSA9IDA7XG4gICAgICAgIGZvciAoaSA9IHBhcnNlSW50KDEpOyBpIDw9IGNvdW50OyBpKyspe1xuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiaWRfYnVpbGRpbmdcIiwgaSk7XG4gICAgICAgICAgICBidWlsZGluZyA9IEpTT04ucGFyc2UoY2Muc3lzLmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYnVpbGRpbmdcIiArIGkudG9TdHJpbmcoKSkpO1xuICAgICAgICAgICAgdmFyIHN0ciA9IGJ1aWxkaW5nLm5hbWUgKyAnICcgKyBidWlsZGluZy5jb3N0ICsgJyAnICsgYnVpbGRpbmcudHlwZTtcbiAgICAgICAgICAgIGNjLmxvZyhzdHIpO1xuICAgICAgICAgICAgY2Muc3lzLmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiaW5mb19sYWJlbF90ZXh0XCIsIHN0ci50b1N0cmluZygpKTtcbiAgICAgICAgICAgIHZhciBsYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMubGFiZWxfcHJlZmFiKTtcbiAgICAgICAgICAgIGluZm8uY29udGVudF9uLmFkZENoaWxkKGxhYmVsKTtcbiAgICAgICAgICAgIGxhYmVsLnNldFBvc2l0aW9uKDAsIDEwMCAtIGkqMjAwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBjYWxsZWQgZXZlcnkgZnJhbWUsIHVuY29tbWVudCB0aGlzIGZ1bmN0aW9uIHRvIGFjdGl2YXRlIHVwZGF0ZSBjYWxsYmFja1xuICAgIC8vIHVwZGF0ZTogZnVuY3Rpb24gKGR0KSB7XG5cbiAgICAvLyB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgICAgICBzcXIgOiBjYy5QcmVmYWIsXG4gICAgICAgIG1hcF9ub2RlIDogY2MuTm9kZSxcbiAgICB9LFxuXG4gICAgLy8gdXNlIHRoaXMgZm9yIGluaXRpYWxpemF0aW9uXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBpLCBqO1xuICAgICAgICBmb3IoaSA9IDA7IGkgPCA0MDsgaSsrKXtcbiAgICAgICAgICAgIGZvcihqID0gMDsgaiA8IDQwOyBqKyspe1xuICAgICAgICAgICAgICAgIHZhciBzcXIgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLnNxcik7XG4gICAgICAgICAgICAgICAgc3FyLnNldFBvc2l0aW9uKGkqMjEsIGoqMjEpO1xuICAgICAgICAgICAgICAgIHRoaXMubWFwX25vZGUuYWRkQ2hpbGQoc3FyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG4gICAgbW91bnQgOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIFxuICAgICAgICBcbiAgICB9LFxuICAgIFxuICAgIFxuICAgIFxuXG4gICAgLy8gY2FsbGVkIGV2ZXJ5IGZyYW1lLCB1bmNvbW1lbnQgdGhpcyBmdW5jdGlvbiB0byBhY3RpdmF0ZSB1cGRhdGUgY2FsbGJhY2tcbiAgICAgdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcbiAgICAgICAgdGhpcy5tYXBfbm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9ET1dOLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdNb3VzZSBkb3duJyk7XG4gICAgICAgIH0sIHRoaXMpO1xuICAgICB9LFxufSk7XG4iLCJjYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICAgICAvLyBmb286IHtcbiAgICAgICAgLy8gICAgZGVmYXVsdDogbnVsbCwgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxuICAgICAgICAvLyAgICB1cmw6IGNjLlRleHR1cmUyRCwgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XG4gICAgICAgIC8vICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxuICAgICAgICAvLyAgICB2aXNpYmxlOiB0cnVlLCAgICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcbiAgICAgICAgLy8gICAgZGlzcGxheU5hbWU6ICdGb28nLCAvLyBvcHRpb25hbFxuICAgICAgICAvLyAgICByZWFkb25seTogZmFsc2UsICAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIGZhbHNlXG4gICAgICAgIC8vIH0sXG4gICAgICAgIC8vIC4uLlxuICAgIH0sXG5cbiAgICAvLyB1c2UgdGhpcyBmb3IgaW5pdGlhbGl6YXRpb25cbiAgICBvbkxvYWQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgXG4gICAgfSxcblxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZSwgdW5jb21tZW50IHRoaXMgZnVuY3Rpb24gdG8gYWN0aXZhdGUgdXBkYXRlIGNhbGxiYWNrXG4gICAgLy8gdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcblxuICAgIC8vIH0sXG59KTtcbiJdLCJzb3VyY2VSb290IjoiIn0=